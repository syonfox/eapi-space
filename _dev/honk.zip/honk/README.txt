WKFO's "Honk" mod for Pioneer.

Installation
------------

1) Extract the 'data' folder in the ZIP archive into your 
Pioneer installation folder (merge with Pioneer's own 'data' 
folder)

2) Done.

Usage
------------

1) While the game is running:
	a) Press F9 for "honk 1".
	b) Press Ctrl+F10 for "honk 2".
	c) Press F10 for "honk 3".
	
1.5) You can change keybinds for this mod by editing the
following file:

/data/pigui/modules/honk.lua

(I didn't bother adding new keybinds to the settings menu.)

Uninstalling
------------

1) Delete all of the following:
	a) /data/pigui/modules/honk.lua
	b) /data/sounds/horn1.ogg
	c) /data/sounds/horn2.ogg
	d) /data/sounds/horn3.ogg
	
2) Done.
