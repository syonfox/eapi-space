local ui = require 'pigui'

local function honk()
		
	if ui.ctrlHeld() then 
	--	ui.playSfx("horn1", 1.0, 1.0) 
	end
	
	if ui.isKeyReleased(ui.keys.f9) then
		print( "ctrl: " .. tostring(ui.ctrlHeld()))
		if ui.ctrlHeld() then 
			ui.playSfx("horn1", 1.0, 1.0) 
		else
			ui.playSfx("horn4", 1.0, 1.0)
		end
	elseif ui.isKeyReleased(ui.keys.f10) then
		ui.playSfx("horn2", 1.0, 1.0)
	elseif ui.isKeyReleased(ui.keys.f11) then
		ui.playSfx("horn1", 1.0, 1.0)
	elseif ui.isKeyReleased(ui.keys.f12) then
		ui.playSfx("horn3", 1.0, 1.0)
	end

end

ui.registerModule("game", honk)

return {}
