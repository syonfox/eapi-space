#!/bin/bash

echo "FOXI BUILD"

echo "do nothing"