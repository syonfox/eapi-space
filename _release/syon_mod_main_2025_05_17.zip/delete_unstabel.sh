read -p "Arr you sure? you want to rm -r dev files. (PROBABLY NOT CTRL + C NOW!)"
rm -r ./ships/_disable
rm -r ./_foxi
rm -r ./dev