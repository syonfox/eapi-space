        --    water = 1,
        --    industrial_machinery = 1, --10
        --    liquor = 1,
        --    metal_alloy = 8, -- 160
        --    precious_medals = 1 -- 180


